import { NextResponse, NextRequest } from "next/server";
import { waManager } from "@/modules/whatsapp/manager";
import { canAccessSession } from "@/lib/api-auth";
import { enforceApiQuota } from "@/lib/rate-limit";
import { proto } from "@whiskeysockets/baileys";

/**
 * @deprecated This endpoint is deprecated. Use POST /api/messages/{sessionId}/forward instead.
 * This endpoint will be removed in a future version.
 */
// POST: Forward message to other chats
export async function POST(request: NextRequest) {
    console.warn('[DEPRECATED] POST /api/messages/forward is deprecated. Use POST /api/messages/{sessionId}/forward instead.');
    try {
        const gate = await enforceApiQuota(request);
        if (gate.error) return gate.error;
        const { user } = gate;

        const body = await request.json();
        const { sessionId, fromJid, messageId, toJids } = body;

        if (!sessionId || !fromJid || !messageId || !toJids || !Array.isArray(toJids)) {
            return NextResponse.json({ status: false, message: "sessionId, fromJid, messageId, and toJids (array) are required", error: "sessionId, fromJid, messageId, and toJids (array) are required" }, { status: 400 });
        }

        if (toJids.length === 0) {
            return NextResponse.json({ status: false, message: "At least one recipient is required", error: "At least one recipient is required" }, { status: 400 });
        }

        // Check if user can access this session
        const canAccess = await canAccessSession(user.id, user.role, sessionId);
        if (!canAccess) {
            return NextResponse.json({ status: false, message: "Forbidden - Cannot access this session", error: "Forbidden - Cannot access this session" }, { status: 403 });
        }

        const instance = waManager.getInstance(sessionId);
        if (!instance?.socket) {
            return NextResponse.json({ status: false, message: "Session not ready", error: "Session not ready" }, { status: 503 });
        }

        // Forward message to each recipient
        for (const toJid of toJids) {
            await instance.socket.sendMessage(toJid, {
                forward: {
                    key: {
                        remoteJid: fromJid,
                        fromMe: false,
                        id: messageId
                    },
                    message: {} as proto.IMessage
                }
            });
        }

        return NextResponse.json({ status: true, message: `Message forwarded to ${toJids.length} recipient(s)` });

    } catch (error) {
        console.error("Forward message error:", error);
        return NextResponse.json({ status: false, message: "Failed to forward message", error: "Failed to forward message" }, { status: 500 });
    }
}
